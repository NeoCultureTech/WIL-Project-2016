﻿namespace prjWil
{
    partial class frmRates
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlDeleteRates = new System.Windows.Forms.Panel();
            this.txbEnterEmpID = new System.Windows.Forms.TextBox();
            this.btnDeleteEmp = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlSearchRates = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnSearchEmp = new System.Windows.Forms.Button();
            this.cmbEmpID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDeleteEmpRec = new System.Windows.Forms.Button();
            this.btnSearchEmpRec = new System.Windows.Forms.Button();
            this.btnAddEmpRec = new System.Windows.Forms.Button();
            this.lblSelect = new System.Windows.Forms.Label();
            this.pnlAddRates = new System.Windows.Forms.Panel();
            this.btnAddEmp = new System.Windows.Forms.Button();
            this.txbEmpID = new System.Windows.Forms.TextBox();
            this.txbPayAmt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previousToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlDeleteRates.SuspendLayout();
            this.pnlSearchRates.SuspendLayout();
            this.pnlAddRates.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlDeleteRates
            // 
            this.pnlDeleteRates.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDeleteRates.Controls.Add(this.txbEnterEmpID);
            this.pnlDeleteRates.Controls.Add(this.btnDeleteEmp);
            this.pnlDeleteRates.Controls.Add(this.label2);
            this.pnlDeleteRates.Location = new System.Drawing.Point(402, 238);
            this.pnlDeleteRates.Name = "pnlDeleteRates";
            this.pnlDeleteRates.Size = new System.Drawing.Size(371, 168);
            this.pnlDeleteRates.TabIndex = 19;
            this.pnlDeleteRates.Visible = false;
            // 
            // txbEnterEmpID
            // 
            this.txbEnterEmpID.Location = new System.Drawing.Point(21, 54);
            this.txbEnterEmpID.Name = "txbEnterEmpID";
            this.txbEnterEmpID.Size = new System.Drawing.Size(100, 20);
            this.txbEnterEmpID.TabIndex = 2;
            // 
            // btnDeleteEmp
            // 
            this.btnDeleteEmp.Location = new System.Drawing.Point(176, 52);
            this.btnDeleteEmp.Name = "btnDeleteEmp";
            this.btnDeleteEmp.Size = new System.Drawing.Size(138, 23);
            this.btnDeleteEmp.TabIndex = 1;
            this.btnDeleteEmp.Text = "Delete";
            this.btnDeleteEmp.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(247, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Enter Employee ID of Employee you wish to delete:";
            // 
            // pnlSearchRates
            // 
            this.pnlSearchRates.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSearchRates.Controls.Add(this.richTextBox1);
            this.pnlSearchRates.Controls.Add(this.btnSearchEmp);
            this.pnlSearchRates.Controls.Add(this.cmbEmpID);
            this.pnlSearchRates.Controls.Add(this.label1);
            this.pnlSearchRates.Location = new System.Drawing.Point(402, 50);
            this.pnlSearchRates.Name = "pnlSearchRates";
            this.pnlSearchRates.Size = new System.Drawing.Size(371, 168);
            this.pnlSearchRates.TabIndex = 18;
            this.pnlSearchRates.Visible = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(21, 58);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(322, 96);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            // 
            // btnSearchEmp
            // 
            this.btnSearchEmp.Location = new System.Drawing.Point(271, 16);
            this.btnSearchEmp.Name = "btnSearchEmp";
            this.btnSearchEmp.Size = new System.Drawing.Size(75, 23);
            this.btnSearchEmp.TabIndex = 2;
            this.btnSearchEmp.Text = "Search";
            this.btnSearchEmp.UseVisualStyleBackColor = true;
            // 
            // cmbEmpID
            // 
            this.cmbEmpID.FormattingEnabled = true;
            this.cmbEmpID.Location = new System.Drawing.Point(131, 16);
            this.cmbEmpID.Name = "cmbEmpID";
            this.cmbEmpID.Size = new System.Drawing.Size(121, 21);
            this.cmbEmpID.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Employee ID:";
            // 
            // btnDeleteEmpRec
            // 
            this.btnDeleteEmpRec.Location = new System.Drawing.Point(168, 108);
            this.btnDeleteEmpRec.Name = "btnDeleteEmpRec";
            this.btnDeleteEmpRec.Size = new System.Drawing.Size(143, 23);
            this.btnDeleteEmpRec.TabIndex = 17;
            this.btnDeleteEmpRec.Text = "Delete Rates Record";
            this.btnDeleteEmpRec.UseVisualStyleBackColor = true;
            this.btnDeleteEmpRec.Click += new System.EventHandler(this.btnDeleteEmpRec_Click);
            // 
            // btnSearchEmpRec
            // 
            this.btnSearchEmpRec.Location = new System.Drawing.Point(168, 79);
            this.btnSearchEmpRec.Name = "btnSearchEmpRec";
            this.btnSearchEmpRec.Size = new System.Drawing.Size(143, 23);
            this.btnSearchEmpRec.TabIndex = 16;
            this.btnSearchEmpRec.Text = "Search Rates Record";
            this.btnSearchEmpRec.UseVisualStyleBackColor = true;
            this.btnSearchEmpRec.Click += new System.EventHandler(this.btnSearchEmpRec_Click);
            // 
            // btnAddEmpRec
            // 
            this.btnAddEmpRec.Location = new System.Drawing.Point(168, 50);
            this.btnAddEmpRec.Name = "btnAddEmpRec";
            this.btnAddEmpRec.Size = new System.Drawing.Size(143, 23);
            this.btnAddEmpRec.TabIndex = 15;
            this.btnAddEmpRec.Text = "Add Rates Record";
            this.btnAddEmpRec.UseVisualStyleBackColor = true;
            this.btnAddEmpRec.Click += new System.EventHandler(this.btnAddEmpRec_Click);
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(34, 50);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(125, 13);
            this.lblSelect.TabIndex = 14;
            this.lblSelect.Text = "Please make a selection:";
            // 
            // pnlAddRates
            // 
            this.pnlAddRates.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddRates.Controls.Add(this.btnAddEmp);
            this.pnlAddRates.Controls.Add(this.txbEmpID);
            this.pnlAddRates.Controls.Add(this.txbPayAmt);
            this.pnlAddRates.Controls.Add(this.label4);
            this.pnlAddRates.Controls.Add(this.label3);
            this.pnlAddRates.Location = new System.Drawing.Point(46, 201);
            this.pnlAddRates.Name = "pnlAddRates";
            this.pnlAddRates.Size = new System.Drawing.Size(328, 152);
            this.pnlAddRates.TabIndex = 13;
            this.pnlAddRates.Visible = false;
            // 
            // btnAddEmp
            // 
            this.btnAddEmp.Location = new System.Drawing.Point(122, 91);
            this.btnAddEmp.Name = "btnAddEmp";
            this.btnAddEmp.Size = new System.Drawing.Size(125, 23);
            this.btnAddEmp.TabIndex = 13;
            this.btnAddEmp.Text = "Add";
            this.btnAddEmp.UseVisualStyleBackColor = true;
            this.btnAddEmp.Click += new System.EventHandler(this.btnAddEmp_Click);
            // 
            // txbEmpID
            // 
            this.txbEmpID.Location = new System.Drawing.Point(119, 42);
            this.txbEmpID.Name = "txbEmpID";
            this.txbEmpID.Size = new System.Drawing.Size(128, 20);
            this.txbEmpID.TabIndex = 8;
            // 
            // txbPayAmt
            // 
            this.txbPayAmt.Location = new System.Drawing.Point(119, 14);
            this.txbPayAmt.Name = "txbPayAmt";
            this.txbPayAmt.Size = new System.Drawing.Size(128, 20);
            this.txbPayAmt.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Employee ID:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Pay Amount:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(807, 24);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.previousToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // previousToolStripMenuItem
            // 
            this.previousToolStripMenuItem.Name = "previousToolStripMenuItem";
            this.previousToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.previousToolStripMenuItem.Text = "Previous";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.logoutToolStripMenuItem.Text = "Logout";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // frmRates
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(807, 456);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pnlDeleteRates);
            this.Controls.Add(this.pnlSearchRates);
            this.Controls.Add(this.btnDeleteEmpRec);
            this.Controls.Add(this.btnSearchEmpRec);
            this.Controls.Add(this.btnAddEmpRec);
            this.Controls.Add(this.lblSelect);
            this.Controls.Add(this.pnlAddRates);
            this.Name = "frmRates";
            this.Text = "frmRates";
            this.pnlDeleteRates.ResumeLayout(false);
            this.pnlDeleteRates.PerformLayout();
            this.pnlSearchRates.ResumeLayout(false);
            this.pnlSearchRates.PerformLayout();
            this.pnlAddRates.ResumeLayout(false);
            this.pnlAddRates.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlDeleteRates;
        private System.Windows.Forms.TextBox txbEnterEmpID;
        private System.Windows.Forms.Button btnDeleteEmp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlSearchRates;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnSearchEmp;
        private System.Windows.Forms.ComboBox cmbEmpID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDeleteEmpRec;
        private System.Windows.Forms.Button btnSearchEmpRec;
        private System.Windows.Forms.Button btnAddEmpRec;
        private System.Windows.Forms.Label lblSelect;
        private System.Windows.Forms.Panel pnlAddRates;
        private System.Windows.Forms.Button btnAddEmp;
        private System.Windows.Forms.TextBox txbEmpID;
        private System.Windows.Forms.TextBox txbPayAmt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem previousToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
    }
}